const dataArray = [];

for (let id = 1; id <= 120; id++) {
  dataArray.push({
    id: id,
    playername: "KING OF HOOVES",
    familytype: "FIRE FAMILY ",
    totatalracewin: "1546 ",
    totalracedistance: "256548",
    winprice: "$15423",
  });
}

export default dataArray;
